CONFIGURATEUR MEGANE IV PHASE 2 — COULEURS / SELLERIE

Cette version reprend le script configurateur précédent.

COULEURS :
Seuls les noms de couleurs déjà présents dans le script précédent ont été conservés.
Les photos affichées sont des recadrages des planches teintier de la brochure fournie.

SELLERIE :
Le script précédent mentionnait la sellerie mixte textile enduit grainé / tissu carbone.
La brochure fournie présente, pour la version Intens, la sellerie correspondante sous le nom :
« Sellerie mixte similicuir / tissu Carbone texturé ».
C'est cette photo et ce libellé de brochure qui sont utilisés pour Techno.

IMPORTANT JANTES :
Les noms/fichiers de jantes existants du script ne sont pas renommés ni remplacés.

Pour GitHub Pages : mettre index.html et le dossier images/ à la racine du dépôt.
